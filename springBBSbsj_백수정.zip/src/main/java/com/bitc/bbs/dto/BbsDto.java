package com.bitc.bbs.dto;

public class BbsDto {

	private int num;
	private String wish;
	private String goalDate;
	private String delYn;
	
	public int getNum() {
		return num;
	}
	
	public void setNum(int num) {
		this.num = num;
	}
	
	public String getWish() {
		return wish;
	}
	
	public void setWish(String wish) {
		this.wish = wish;
	}
	
	public String getGoalDate() {
		return goalDate;
	}
	
	public void setGoal_date(String goalDate) {
		this.goalDate = goalDate;
	}

	public String getDelYn() {
		return delYn;
	}

	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	
	
}
